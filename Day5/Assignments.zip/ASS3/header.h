void prime_factor(int );
