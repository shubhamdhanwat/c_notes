#include<stdio.h>
#include"header.h"

int main()
{
    int num;
    printf("Enter the number :");
    scanf("%d",&num);
    checkprime(num);
    return 0;
}