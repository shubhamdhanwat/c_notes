#include<stdio.h>
#include"header.h"
int main()
{
    int num1,num2;
    printf("Enter the numbers num1 and num2 :");
    scanf("%d%d",&num1,&num2);
    RangeSquare(num1,num2);
    return 0;
}