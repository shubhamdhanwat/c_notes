void RangeSquare(int,int);
