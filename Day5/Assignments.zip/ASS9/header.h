int countdigit(int);
int checkarmstrong(int,int);
