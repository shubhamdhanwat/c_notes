int factorial(int);
int display(int);
int count_digit(int);
int reverse_number(int,int);
