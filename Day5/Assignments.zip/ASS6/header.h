int printSeries(int);
