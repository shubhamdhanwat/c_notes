#include<stdio.h>
#include"header.h"

int checknum(int num)
{
    if(num%2==0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}