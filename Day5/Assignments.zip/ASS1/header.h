int checknum(int );
