int checkNumber(int);
int getNumber(int);